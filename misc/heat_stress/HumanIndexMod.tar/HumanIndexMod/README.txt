# execute compile_humIM.csh
#modify EXE_HumanIndexMod.csh
#execute EXE_HumanIndexMod.csh

#ncl script is designed for Time,Lat,Lon files.
#Need to modify ncl script for input vars:  T,P,Q,RH,U10.

#Good Luck

#Citation:
#Buzan, J. R., K. Oleson, and M. Huber (2015), Implementation and comparison of a suite of heat stress metrics within the Community Land Model version 4.5, Geosci. Model Dev., 8(2), 151–170, doi:10.5194/gmd-8-151-2015.

#Not for commercial use
